class Url {
    getRoute() {
        return window.location.pathname;
    }
}

export default Url;