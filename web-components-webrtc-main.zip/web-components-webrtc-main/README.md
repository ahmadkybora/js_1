# web-components-webrtc

Live at: https://web-components-webrtc.web.app

# Start

- Install Node.js LTS
- run `npm run start`

# Deploy to firebase hosting

- npm run build
- firebase projects:list
- firebase use web-components-webrtc
- firebase deploy
  https://web-components-webrtc.web.app
